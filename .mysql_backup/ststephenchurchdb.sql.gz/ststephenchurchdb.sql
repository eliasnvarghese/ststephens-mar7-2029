-- MariaDB dump 10.19  Distrib 10.6.16-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: ststephenchurchdb
-- ------------------------------------------------------
-- Server version	10.6.16-MariaDB-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `ststephenchurchdb`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ststephenchurchdb` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;

USE `ststephenchurchdb`;

--
-- Table structure for table `admin_loginactivity`
--

DROP TABLE IF EXISTS `admin_loginactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_loginactivity` (
  `userid` varchar(100) NOT NULL DEFAULT '',
  `logintime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastupdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ipaddress` varchar(100) NOT NULL DEFAULT '',
  `hashkey` varchar(100) NOT NULL DEFAULT '',
  `sessionid` varchar(100) NOT NULL DEFAULT '',
  `hostname` varchar(100) NOT NULL DEFAULT '',
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdby` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_loginactivity`
--

LOCK TABLES `admin_loginactivity` WRITE;
/*!40000 ALTER TABLE `admin_loginactivity` DISABLE KEYS */;
INSERT INTO `admin_loginactivity` VALUES ('antony','2019-03-07 11:36:26','2019-03-07 11:36:26','122.164.229.152','3716114b005e9b4e533c7f3cd0f4f253','9d3b665f5165ab3474e389f5e78f1411','','2019-03-07 06:06:26',''),('eliasnvarghese@gmail.com','2020-07-06 03:43:59','2020-07-06 03:43:59','161.69.122.15','bbf3f7d34f8c97aa9ed9b970e48f102b','784226a275978782f668cdb2863518ac','','2020-07-05 22:13:59',''),('ginojohn@gmail.com','2024-02-05 05:39:52','2024-02-05 05:39:52','73.189.123.159','c4c07b88493f8da84802bcd2a7de351a','5b76345129e75fb300c04f097c5dc15e','','2024-02-05 00:09:52','');
/*!40000 ALTER TABLE `admin_loginactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_user_details_t`
--

DROP TABLE IF EXISTS `admin_user_details_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_user_details_t` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(100) NOT NULL DEFAULT '',
  `username` varchar(100) NOT NULL DEFAULT '',
  `firstname` varchar(50) NOT NULL DEFAULT '',
  `lastname` varchar(50) NOT NULL DEFAULT '',
  `gender` varchar(1) NOT NULL DEFAULT '',
  `passwd` varchar(100) NOT NULL DEFAULT '',
  `saltkey` varchar(200) NOT NULL DEFAULT '',
  `sessionid` varchar(200) NOT NULL DEFAULT '',
  `activationdata` varchar(200) NOT NULL DEFAULT '',
  `activated` int(11) NOT NULL DEFAULT 0,
  `activatedon` datetime NOT NULL,
  `organizationname` varchar(100) NOT NULL DEFAULT '',
  `designation` varchar(100) NOT NULL DEFAULT '',
  `address` varchar(300) NOT NULL DEFAULT '',
  `city` varchar(100) NOT NULL DEFAULT '',
  `state` varchar(100) NOT NULL DEFAULT '',
  `country` varchar(100) NOT NULL DEFAULT '',
  `zipcode` varchar(10) NOT NULL DEFAULT '',
  `dob` datetime NOT NULL,
  `contactnumber` varchar(100) NOT NULL DEFAULT '',
  `mobilenumber` varchar(20) NOT NULL DEFAULT '',
  `securityquestion` varchar(100) NOT NULL DEFAULT '',
  `securityanswer` varchar(100) NOT NULL DEFAULT '',
  `altemailid` varchar(100) NOT NULL DEFAULT '',
  `photopath` varchar(200) NOT NULL DEFAULT '',
  `imagetype` varchar(5) NOT NULL DEFAULT '',
  `coverphoto` varchar(200) NOT NULL DEFAULT '',
  `tagline` longtext NOT NULL,
  `aboutme` longtext NOT NULL,
  `themeid` int(11) NOT NULL DEFAULT 0,
  `profilesecurity` int(11) NOT NULL DEFAULT 0,
  `community` varchar(100) NOT NULL DEFAULT '',
  `country_code` varchar(10) NOT NULL DEFAULT '',
  `region_code` varchar(10) NOT NULL DEFAULT '',
  `longitude` varchar(10) NOT NULL DEFAULT '',
  `latitude` varchar(10) NOT NULL DEFAULT '',
  `timezone` varchar(20) NOT NULL DEFAULT '',
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdby` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_user_details_t`
--

LOCK TABLES `admin_user_details_t` WRITE;
/*!40000 ALTER TABLE `admin_user_details_t` DISABLE KEYS */;
INSERT INTO `admin_user_details_t` VALUES (1,'antony','','Antony Joseph','','m','nubmv3p1b4WToA==','xrPY5LTam6KQnZuXnJuVe4SmeJuapZmVow==','','',1,'0000-00-00 00:00:00','','','','Cochin','','','','0000-00-00 00:00:00','','32423423','','','','','','','','',0,0,'','','','','','','2014-05-14 21:10:00',''),(4,'ginojohn@gmail.com','','Gino John','','','pOO66Zqpp2s=','zLziwt7U2Nal1bDJ3t6Ry87SoJeappKEpYCmnZCZmah3ma+ilw==','','',1,'2018-11-28 14:41:04','','','','CA USA','','','','2018-11-28 14:41:04','','111111111111111','','','','','','','','',0,0,'','','','','','','2018-11-28 09:11:04',''),(6,'eliasnvarghese@gmail.com','','Elias N Varghese','','','ouXbkNelgZk=','yr/dtOfT5snX1avN6Nejz8zG19OX0dTApoOmlZ2YnJtznpWilqKTmKibng==','','',1,'2020-07-06 03:43:45','','','','Mountain House','','','','2020-07-06 03:43:45','','0000','','','','','','','','',0,0,'','','','','','','2020-07-05 22:13:45','');
/*!40000 ALTER TABLE `admin_user_details_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cashreceipt_t`
--

DROP TABLE IF EXISTS `cashreceipt_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cashreceipt_t` (
  `rectno` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL DEFAULT 0,
  `serialno` int(11) NOT NULL DEFAULT 0,
  `rectdate` datetime DEFAULT NULL,
  `categorycode` varchar(10) NOT NULL DEFAULT '',
  `rectdetls` varchar(500) NOT NULL DEFAULT '',
  `rectamount` float NOT NULL DEFAULT 0,
  `cancelled` int(1) NOT NULL DEFAULT 0,
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdby` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`rectno`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cashreceipt_t`
--

LOCK TABLES `cashreceipt_t` WRITE;
/*!40000 ALTER TABLE `cashreceipt_t` DISABLE KEYS */;
INSERT INTO `cashreceipt_t` VALUES (1,3441,0,'2018-01-10 00:00:00','Offerings','For Testing',50,0,'2018-12-13 15:58:13',''),(2,3441,0,'2018-01-11 00:00:00','Donation','for testing',250,0,'2018-12-13 16:07:39',''),(3,3441,0,'2018-01-09 00:00:00','Offerings','dsfgdsfgdfgdsfg',50,0,'2018-12-13 16:11:15',''),(4,3441,0,'2018-01-09 00:00:00','Offerings','dsfgdsfgdfgdsfg',50,0,'2018-12-13 16:15:10',''),(5,3441,0,'2018-01-09 00:00:00','Offerings','dsfgdsfgdfgdsfg',50,0,'2018-12-13 16:16:52',''),(6,3441,0,'2018-01-09 00:00:00','Offerings','dsfgdsfgdfgdsfg dsfsdaf',125,0,'2018-12-13 16:20:50',''),(7,3441,0,'2018-12-14 00:00:00','Offerings','Donation for christmas celebrations',50,0,'2018-12-14 03:21:06',''),(8,3441,0,'2018-12-04 00:00:00','Offerings','test receipt pdf mail',11,0,'2018-12-17 09:52:31',''),(9,3441,0,'2018-12-12 00:00:00','Offerings','test receipt pdf mail 12',12,0,'2018-12-17 11:15:42',''),(10,3441,0,'2018-12-11 00:00:00','Offerings','Donation for christmas celebrations 11',11,0,'2018-12-17 11:32:52',''),(11,3449,0,'2018-12-17 00:00:00','Donation','Just for Testing Purpose ',100,0,'2018-12-17 11:36:02','');
/*!40000 ALTER TABLE `cashreceipt_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events_t`
--

DROP TABLE IF EXISTS `events_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events_t` (
  `eventid` int(11) NOT NULL AUTO_INCREMENT,
  `fromdate` datetime NOT NULL,
  `todate` datetime NOT NULL,
  `highlights` varchar(200) DEFAULT '',
  `eventdetails` longtext NOT NULL,
  `clickscount` int(11) NOT NULL DEFAULT 0,
  `eventname` varchar(100) NOT NULL DEFAULT '',
  `deleted` int(1) NOT NULL DEFAULT 0,
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdby` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`eventid`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events_t`
--

LOCK TABLES `events_t` WRITE;
/*!40000 ALTER TABLE `events_t` DISABLE KEYS */;
INSERT INTO `events_t` VALUES (13,'2018-12-02 00:00:00','2018-12-02 00:00:00','sdfsdfdsfsdfsdf','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\nLocation: \r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Mass',1,'2018-11-26 18:31:59',''),(14,'2018-12-16 00:00:00','2018-12-16 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\nLocation: \r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Qurbono',1,'2018-11-26 18:34:02',''),(15,'2018-12-30 00:00:00','2018-12-30 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\nLocation: \r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Qurbono',1,'2018-11-26 18:36:17',''),(16,'2018-12-09 00:00:00','2018-12-09 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\nLocation: \r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Qurbono',1,'2018-12-07 05:01:40',''),(17,'2019-03-10 00:00:00','2019-03-10 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\nLocation: \r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Qurbono',1,'2018-12-20 02:48:49',''),(18,'2019-01-06 00:00:00','2019-01-06 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\nLocation: \r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Qurbono',1,'2018-12-07 05:42:37',''),(19,'2019-01-13 00:00:00','2019-01-13 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\nLocation: \r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Qurbono',1,'2018-12-07 05:43:00',''),(20,'2019-01-20 00:00:00','2019-01-20 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\nLocation: \r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Qurbono',1,'2018-12-07 05:43:27',''),(21,'2019-01-27 00:00:00','2019-01-27 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\nLocation: \r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Qurbono',1,'2018-12-07 05:43:55',''),(22,'2019-02-03 00:00:00','2019-02-03 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\nLocation: \r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Qurbono',1,'2018-12-07 05:44:22',''),(23,'2019-02-10 00:00:00','2019-02-10 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\nLocation: \r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,' St. Ignatius Feast & Holy Qurbono',1,'2019-02-04 17:02:14',''),(24,'2019-02-17 00:00:00','2019-02-17 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\nLocation: \r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Qurbono',1,'2018-12-07 05:45:18',''),(25,'2019-02-24 00:00:00','2019-02-24 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\nLocation: \r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Qurbono',1,'2018-12-07 05:46:00',''),(26,'2019-03-03 00:00:00','2019-03-03 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\nLocation: \r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Qurbono',1,'2018-12-07 05:46:28',''),(27,'2018-11-01 00:00:00','2018-11-01 00:00:00','Testing','testing the event',0,'Testing',1,'2019-01-24 02:45:49',''),(28,'2019-02-03 00:00:00','2019-02-03 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM - Sunday School\r\nLocation:\r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA\r\n',0,'Holy Qurbono',1,'2019-01-25 05:21:46',''),(29,'2019-02-17 00:00:00','2019-02-17 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM - Sunday School\r\nLocation:\r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Qurbono',1,'2019-01-28 14:46:19',''),(30,'2019-03-03 00:00:00','2019-03-03 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM - Sunday School\r\nLocation:\r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Qurbono',1,'2019-01-28 15:04:15',''),(31,'2019-03-17 00:00:00','2019-03-17 00:00:00','Holy Qurbono','7:15 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM - Sunday School\r\nLocation:\r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'3rd Sunday of Lent',1,'2019-03-17 13:46:36',''),(32,'2019-03-24 00:00:00','2019-03-24 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM - Sunday School\r\nLocation:\r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'4th Sunday of Lent',1,'2019-03-17 13:47:09',''),(33,'2019-03-31 00:00:00','2019-03-31 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM - Sunday School\r\nLocation:\r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'5th Sunday of Lent',1,'2019-03-17 13:48:30',''),(34,'2019-04-06 00:00:00','2019-04-06 00:00:00','Lenten Retreat','Lenten Retreat \r\n\r\nTime: 2 PM - 6:00 PM\r\nRetreat, Confession  & Evening Prayer\r\nLocation:\r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Lenten Retreat (Saturday)',1,'2019-03-17 13:52:44',''),(35,'2019-04-07 00:00:00','2019-04-07 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM - Sunday School\r\nLocation:\r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'6th Sunday of Lent',1,'2019-03-17 13:54:13',''),(36,'2019-04-14 00:00:00','2019-04-14 00:00:00','Palm Sunday (oosha`nÃ©)','6:30 AM - Morning Prayer\r\n7:00 AM - Hosanna Service\r\n9:15 AM - Holy Qurbono\r\nLocation:\r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Palm Sunday (oosha`nÃ©)',1,'2019-04-14 17:22:20',''),(37,'2019-04-17 00:00:00','2019-04-17 00:00:00','Pesaha (Wednesday Evening)','Pesaha\r\n\r\nEvening Prayer: 6:00 PM\r\nPesaha Qurbono: 7:30 PM\r\nLocation:\r\nSt. Thomas Church, \r\n1921 Las Palmas Ave, San Jose CA',0,'Pesaha (Wednesday Evening)',1,'2019-04-14 17:27:00',''),(38,'2019-04-19 00:00:00','2019-04-19 00:00:00','Good Friday','Good Friday\r\n\r\nMorning Prayer: 8:00 AM\r\n\r\nLocation:\r\nSt. Thomas Church, \r\n1921 Las Palmas Ave, San Jose CA',0,'Good Friday',1,'2019-04-14 17:30:09',''),(39,'2019-04-20 00:00:00','2019-04-20 00:00:00','Easter (Saturday Evening)','Easter(Sunday of resurrection)\r\n\r\nEvening Prayer: 6:00 PM\r\nEaster Service : 7:00 PM\r\n Holy Qurbono: 7:30 PM',0,'Easter (Saturday Evening)',1,'2019-04-14 17:32:47',''),(40,'2019-04-28 00:00:00','2019-04-28 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM - Sunday School\r\nLocation:\r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Qurbono',1,'2019-04-14 17:33:35',''),(41,'2019-05-05 00:00:00','2019-05-05 00:00:00','Holy Qurbono','7:30 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\nLocation: \r\nSt. Thomas Church, 1921 Las Palmas Ave, San Jose CA',0,'Holy Qurbono',1,'2019-04-14 17:34:28',''),(42,'2019-05-12 00:00:00','2019-05-12 00:00:00','Holy Qurbono','7:15 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\n\r\nAddress:  1921 Las Pulmas Ave, San Jose CA\r\n',0,'Holy Qurbono',1,'2019-05-06 15:32:09',''),(43,'2019-05-19 00:00:00','2019-05-19 00:00:00','Holy Qurbono','7:15 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\n\r\nAddress:  1921 Las Pulmas Ave, San Jose CA',0,'Holy Qurbono',1,'2019-05-06 15:31:56',''),(44,'2019-05-26 00:00:00','2019-05-26 00:00:00','Holy Qurbono','7:15 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\n\r\nAddress:  1921 Las Pulmas Ave, San Jose CA',0,'Holy Qurbono',1,'2019-05-06 15:32:58',''),(45,'2019-06-02 00:00:00','2019-06-02 00:00:00','Holy Qurbono','7:15 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\n\r\nAddress:  1921 Las Pulmas Ave, San Jose CA',0,'Holy Qurbono',1,'2019-05-06 15:33:25',''),(46,'2019-06-09 00:00:00','2019-06-09 00:00:00','Holy Qurbono','7:15 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\n\r\nAddress:  1921 Las Pulmas Ave, San Jose CA',0,'Holy Qurbono',1,'2019-05-06 15:33:45',''),(47,'2019-06-16 00:00:00','2019-06-16 00:00:00','Holy Qurbono','7:15 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\n\r\nAddress:  1921 Las Pulmas Ave, San Jose CA',0,'Holy Qurbono',1,'2019-05-06 15:34:03',''),(48,'2019-06-23 00:00:00','2019-06-23 00:00:00','Holy Qurbono','7:15 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\n\r\nAddress:  1921 Las Pulmas Ave, San Jose CA',0,'Holy Qurbono',1,'2019-05-06 15:34:21',''),(49,'2019-06-30 00:00:00','2019-06-30 00:00:00','Holy Qurbono','7:15 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\n\r\nAddress:  1921 Las Pulmas Ave, San Jose CA',0,'Holy Qurbono',1,'2019-05-06 15:34:40',''),(50,'2019-07-07 00:00:00','2019-07-07 00:00:00','Holy Qurbono','7:15 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\n\r\nAddress:  1921 Las Pulmas Ave, San Jose CA',0,'Holy Qurbono',1,'2019-05-06 15:34:59',''),(51,'2019-07-14 00:00:00','2019-07-14 00:00:00','Holy Qurbono','7:15 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School',0,'Holy Qurbono',1,'2019-07-07 10:34:52',''),(52,'2019-07-21 00:00:00','2019-07-21 00:00:00','Holy Qurbono','7:15 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School',0,'Holy Qurbono',1,'2019-07-07 10:35:10',''),(53,'2019-07-28 00:00:00','2019-07-28 00:00:00','Holy Qurbono','No Holy Qurbono\r\n',0,'Holy Qurbono',1,'2019-07-27 14:42:25',''),(54,'2019-08-04 00:00:00','2019-08-04 00:00:00','Holy Qurbono','7:15 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\n\r\nAddress:  1921 Las Pulmas Ave, San Jose CA',0,'Holy Qurbono',1,'2019-07-07 10:37:05',''),(55,'2019-08-11 00:00:00','2019-08-11 00:00:00','Holy Qurbono','7:15 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\n\r\nAddress:  1921 Las Pulmas Ave, San Jose CA',0,'Holy Qurbono',1,'2019-07-07 10:37:23',''),(56,'2019-08-18 00:00:00','2019-08-18 00:00:00','Holy Qurbono','7:15 AM - Morning Prayer\r\n8:00 AM - Holy Qurbono\r\n9:15 AM -  Sunday School\r\n\r\nAddress:  1921 Las Pulmas Ave, San Jose CA',0,'Holy Qurbono',1,'2019-07-07 10:37:46',''),(57,'2020-07-04 00:00:00','2020-07-04 00:00:00','Holy Qurbono','8:15 AM - Holy Qurbono\r\n9:30 AM -  Sunday School\r\n\r\nAddress:  1921 Las Pulmas Ave, San Jose CA',0,'2nd Sunday of Lent ',1,'2020-07-06 10:29:09',''),(58,'2023-03-05 00:00:00','2023-03-05 00:00:00','Sunday of The Paralytic(msharyo)','Sunday of The Paralytic (msharyo)\r\n\r\nHoly Qurbono: 8:30 AM\r\n\r\nAddress: 1921 Las Plumas Ave, San Jose, CA 95133',0,'3rd Sunday of Lent',1,'2023-02-27 12:40:51',''),(59,'2020-03-15 00:00:00','2020-03-15 00:00:00','Sunday of the Canaanite woman (kna`nayto)','8:15 AM - Holy Qurbono\r\n9:30 AM -  Sunday School\r\n\r\nAddress:  1921 Las Pulmas Ave, San Jose CA',0,'4th Sunday of Lent',1,'2020-02-24 11:27:00',''),(60,'2020-03-22 00:00:00','2020-03-22 00:00:00','Sunday of the hunchback woman (kfofto)','8:15 AM - Holy Qurbono\r\n9:30 AM -  Sunday School\r\n\r\nAddress:  1921 Las Pulmas Ave, San Jose CA',0,'5th Sunday of Lent',1,'2020-02-24 11:29:21',''),(61,'2023-03-26 00:00:00','2023-03-26 00:00:00','Sunday of the healing of the Blind man (Samyo)','Sunday of the healing of the Blind man (Samyo)\r\n\r\nMorning Prayer - 8:00 AM\r\nHoly Qurbana - 8:30 AM\r\nSunday School - 9:45 AM',0,'6th Sunday of Lent',0,'2023-02-27 13:06:48',''),(62,'2023-04-02 00:00:00','2023-04-02 00:00:00','Palm Sunday (oosha`nÃ©)','Palm Sunday (oosha`nÃ©)\r\n\r\nPalm Sunday & Holy Qurbono: 7:30 AM',0,'Palm Sunday (oosha`nÃ©)',0,'2023-02-27 12:58:13',''),(63,'2020-07-06 00:00:00','2020-07-06 00:00:00','Daily Evening Prayer @6:30 PM','Daily Evening Prayer @6:30 PM',0,'Daily Evening Prayer @6:30 PM',1,'2020-07-06 11:31:40',''),(64,'2020-07-07 00:00:00','2020-07-07 00:00:00','Daily Evening Prayer @6:30 PM','Daily Evening Prayer @6:30 PM',0,'Daily Evening Prayer @6:30 PM PST',1,'2020-07-06 11:33:59',''),(65,'2020-07-06 00:00:00','2020-07-06 00:00:00','Daily Online Evening Prayer @6:30 PM','Daily Evening Prayer @6:30 PM PST',0,'Daily Online Evening Prayer @6:30 PM',1,'2020-07-06 11:33:37',''),(66,'2020-07-08 00:00:00','2020-07-08 00:00:00','Daily Evening Prayer @6:30 PM PST','Daily Evening Prayer @6:30 PM PST',0,'Daily Evening Prayer @6:30 PM PST',1,'2020-07-06 11:34:27',''),(67,'2020-07-09 00:00:00','2020-07-09 00:00:00','Daily Evening Prayer @6:30 PM PST','Daily Evening Prayer @6:30 PM PST',0,'Daily Evening Prayer @6:30 PM PST',1,'2020-07-06 11:34:37',''),(68,'2020-07-10 00:00:00','2020-07-10 00:00:00','Daily Evening Prayer @6:30 PM PST','Daily Evening Prayer @6:30 PM PST',0,'Daily Evening Prayer @6:30 PM PST',1,'2020-07-06 11:34:48',''),(69,'2020-07-11 00:00:00','2020-07-11 00:00:00','Daily Evening Prayer @6:30 PM PST','Daily Evening Prayer @6:30 PM PST',0,'Daily Evening Prayer @6:30 PM PST',1,'2020-07-06 11:35:02',''),(70,'2020-07-12 00:00:00','2020-07-12 00:00:00','Daily Evening Prayer @6:30 PM PST','Daily Evening Prayer @6:30 PM PST',0,'Daily Evening Prayer @6:30 PM PST',1,'2020-07-06 11:35:48',''),(71,'2022-04-24 00:00:00','2022-04-24 00:00:00','Holy Qurbono','Holy Qurbono @8:30 AM',0,'Holy Qurbono',1,'2022-04-11 10:02:59',''),(72,'2022-05-01 00:00:00','2022-05-01 00:00:00','Holy Qurbana','Holy Qurbana - 8:30 AM',0,'Holy Qurbana',1,'2022-04-11 10:04:18',''),(73,'2020-07-15 00:00:00','2020-07-15 00:00:00','Daily Evening Prayer @6:30 PM PST','Daily Evening Prayer @6:30 PM PST',0,'Daily Evening Prayer @6:30 PM PST',1,'2020-07-06 11:36:16',''),(74,'2020-07-16 00:00:00','2020-07-16 00:00:00','Daily Evening Prayer @6:30 PM PST','Daily Evening Prayer @6:30 PM PST',0,'Daily Evening Prayer @6:30 PM PST',1,'2020-07-06 11:36:26',''),(75,'2020-07-18 00:00:00','2020-07-18 00:00:00','Daily Evening Prayer @6:30 PM PST','Daily Evening Prayer @6:30 PM PST',0,'Daily Evening Prayer @6:30 PM PST',1,'2020-07-06 11:36:41',''),(76,'2023-04-05 00:00:00','2023-04-05 00:00:00','Pesaha','Pesaha\r\n\r\nEvening Prayer: 6:00 PM\r\nPesaha Qurbono: 7:00 PM',0,'Pesaha (Wednesday Evening)',0,'2023-02-27 12:59:44',''),(77,'2023-04-01 00:00:00','2023-04-01 00:00:00','Lenten Retreat','Lenten Retreat & Evening Prayer\r\n\r\nTime: 2 PM - 5:00 PM',0,'Lenten Retreat (Saturday)',0,'2023-02-27 12:56:44',''),(78,'2023-04-07 00:00:00','2023-04-07 00:00:00','Good Friday','Good Friday\r\n\r\nMorning Prayer: 8:00 AM\r\nGood Friday Service: 9:00 AM',0,'Good Friday',0,'2023-02-27 13:00:43',''),(79,'2023-04-08 00:00:00','2023-04-08 00:00:00','Easter(Sunday of resurrection)','Easter(Sunday of resurrection)\r\n\r\nEvening Prayer: 5:00 PM\r\nEaster Service & Holy Qurbono: 6:00 PM',0,'Easter (Saturday Evening)',0,'2023-02-27 13:01:34',''),(80,'2022-05-08 00:00:00','2022-05-08 00:00:00','Holy Qurbana','Holy Qurbana @8:30 AM',0,'Holy Qurbana',1,'2022-04-11 10:05:13',''),(81,'2022-05-15 00:00:00','2022-05-15 00:00:00','Holy Qurbana','Holy Qurbana @8:30 AM',0,'Holy Qurbana',1,'2022-04-11 10:05:44',''),(82,'2023-04-16 00:00:00','2023-04-16 00:00:00','Holy Qurbana','Holy Qurbana @8:30 AM',0,'Holy Qurbana 8:30 AM PST',0,'2023-02-27 13:02:42',''),(83,'2022-12-24 00:00:00','2022-12-24 00:00:00','Christmas Service Dec 24 5:30 PM','Christmas Service Dec 24 5:30 PM PST',0,'Christmas Service Dec 24 5:30 PM PST',1,'2022-12-24 16:35:24',''),(84,'2023-01-07 00:00:00','2023-01-07 00:00:00','Feast of St.Stephens','Feast of St.Stephens @8:30 AM PST',0,'Feast of St.Stephens',1,'2022-12-24 16:37:07',''),(85,'2023-03-12 00:00:00','2023-03-12 00:00:00','Sunday of the Canaanite woman (kna`nayto)','Sunday of the Canaanite woman (kna`nayto)\r\n\r\nMorning Prayer - 8:00 AM\r\nHoly Qurbana - 8:30 AM\r\nSunday School - 9:45 AM',0,'4th Sunday of Lent',0,'2023-02-27 13:06:21',''),(86,'2023-03-05 00:00:00','2023-03-05 00:00:00','Sunday of The Paralytic(msharyo)','Sunday of The Paralytic (msharyo)\r\n\r\nMorning Prayer - 8:00 AM\r\nHoly Qurbana - 8:30 AM\r\nSunday School - 9:45 AM',0,'3rd Sunday of Lent',0,'2023-02-27 13:05:56',''),(87,'2023-03-19 00:00:00','2023-03-19 00:00:00','Sunday of the hunchback woman (kfofto)','Sunday of the hunchback woman (kfofto)\r\n\r\nMorning Prayer - 8:00 AM\r\nHoly Qurbana - 8:30 AM\r\nSunday School - 9:45 AM',0,'5th Sunday of Lent',0,'2023-02-27 13:06:32',''),(88,'2023-04-23 00:00:00','2023-04-23 00:00:00','Holy Qurbana','Morning Prayer - 8:00 AM\r\nHoly Qurbana - 8:30 AM\r\nSunday School - 9:45 AM',0,'Holy Qurbana 8:30 AM PST',0,'2023-02-27 13:04:12',''),(89,'2023-04-30 00:00:00','2023-04-30 00:00:00','Holy Qurbana','Morning Prayer - 8:00 AM\r\nHoly Qurbana - 8:30 AM\r\nSunday School - 9:45 AM',0,'Holy Qurbana 8:30 AM PST',0,'2023-02-27 13:05:25','');
/*!40000 ALTER TABLE `events_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expense_head_t`
--

DROP TABLE IF EXISTS `expense_head_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expense_head_t` (
  `expensecode` int(4) NOT NULL AUTO_INCREMENT,
  `description` varchar(500) NOT NULL DEFAULT '',
  `cancelled` int(1) NOT NULL DEFAULT 0,
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdby` varchar(100) NOT NULL DEFAULT '',
  KEY `expensecode` (`expensecode`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expense_head_t`
--

LOCK TABLES `expense_head_t` WRITE;
/*!40000 ALTER TABLE `expense_head_t` DISABLE KEYS */;
INSERT INTO `expense_head_t` VALUES (1,'Office Expense',0,'2014-11-13 22:41:25','CA30'),(2,'Travelling Expense',0,'2014-11-13 22:48:23','CA30'),(3,'Electicity Charge',0,'2014-11-13 22:52:53','CA30'),(4,'Internet Charge',0,'2014-11-13 22:54:05','CA30'),(5,'Printing & Statonery',0,'2014-11-13 22:56:33','CA30'),(6,'Miscellaneous Expenses',0,'2014-11-26 22:37:06','CA30'),(7,'Telephone Charges',0,'2015-01-22 18:47:29','CA30'),(8,'News Paper & Periodicals',0,'2015-01-30 21:10:23','CA30');
/*!40000 ALTER TABLE `expense_head_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses_t`
--

DROP TABLE IF EXISTS `expenses_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses_t` (
  `expenseid` int(4) NOT NULL AUTO_INCREMENT,
  `expensecode` int(11) NOT NULL DEFAULT 0,
  `transdate` date NOT NULL,
  `narration` varchar(500) NOT NULL DEFAULT '',
  `amount` float NOT NULL DEFAULT 0,
  `cancelled` int(1) NOT NULL DEFAULT 0,
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdby` varchar(100) NOT NULL DEFAULT '',
  KEY `expenseid` (`expenseid`)
) ENGINE=InnoDB AUTO_INCREMENT=316 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses_t`
--

LOCK TABLES `expenses_t` WRITE;
/*!40000 ALTER TABLE `expenses_t` DISABLE KEYS */;
INSERT INTO `expenses_t` VALUES (308,1,'2019-01-01','sdafsdaf',3434,0,'2019-01-02 14:34:47',''),(309,2,'2019-02-01','saffsdfasdfsa',211,0,'2019-01-02 14:35:12',''),(310,2,'2019-01-07','sdfsadfsdf',22,0,'2019-01-08 00:19:30',''),(311,1,'2019-01-02','sdsad',33,0,'2019-01-08 00:19:48',''),(312,4,'2019-01-07','asASASASASas',50,0,'2019-01-08 00:20:26',''),(313,6,'2019-01-04','sadasdasdsad',150,0,'2019-01-08 00:34:08',''),(314,5,'2019-01-08','For Printing',50,0,'2019-01-08 10:04:59',''),(315,3,'2019-01-08','Testomg electricity',100,0,'2019-01-08 10:06:33','');
/*!40000 ALTER TABLE `expenses_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galleryimages_t`
--

DROP TABLE IF EXISTS `galleryimages_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleryimages_t` (
  `imageid` int(11) NOT NULL AUTO_INCREMENT,
  `imagetype` varchar(100) NOT NULL DEFAULT '',
  `filename` varchar(200) NOT NULL DEFAULT '',
  `title` varchar(100) NOT NULL DEFAULT '',
  `description` varchar(500) NOT NULL DEFAULT '',
  `deleted` int(1) NOT NULL DEFAULT 0,
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdby` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`imageid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleryimages_t`
--

LOCK TABLES `galleryimages_t` WRITE;
/*!40000 ALTER TABLE `galleryimages_t` DISABLE KEYS */;
/*!40000 ALTER TABLE `galleryimages_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gospel_t`
--

DROP TABLE IF EXISTS `gospel_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gospel_t` (
  `gospelid` int(11) NOT NULL AUTO_INCREMENT,
  `gospel` varchar(1000) DEFAULT '',
  `bookof` varchar(100) DEFAULT '',
  `deleted` int(1) NOT NULL DEFAULT 0,
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdby` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`gospelid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gospel_t`
--

LOCK TABLES `gospel_t` WRITE;
/*!40000 ALTER TABLE `gospel_t` DISABLE KEYS */;
INSERT INTO `gospel_t` VALUES (1,'Again I say to you that if two of you agree on earth concerning anything that they ask, it will be done for them by My Father in heaven. For where two or more are gathered together in My Name, I am there in the midst of them. ','Matthew 18: 19-20 ',0,'2018-11-20 22:05:31',''),(2,'Jesus did many other signs in the presence of the disciples, which are not written in this book; but these are written so that you may believe that Jesus is the Christ, the Son of God, and that by believing you may have life in his name','John 20:30-31',0,'2018-11-20 22:08:48',''),(9,'For if you love those who love you, what reward have you? Do not even the tax collectors do the same? And if you greet your brethren only, what do you do more than others? Do not even the tax collectors do so? Therefore you shall be perfect, just as your Father in heaven is perfect ','Matthew 5:46-48',0,'2018-11-22 22:26:50',''),(10,'There is no fear in love; but perfect love casts out fear, because fear involves torment. But he who fears has not been made perfect in love. We love Him because He first loved us. If someone says, \"I love God,\" and hates his brother, he is a liar; for he who does not love his brother whom he has seen, how can he love God whom he has not seen? And this commandment we have from Him: that he who loves God must love his brother also ','John 4:18-21',0,'2018-11-22 22:30:59',''),(11,'test rest','Matthew 18: 19-20 ',1,'2018-11-28 09:26:55','');
/*!40000 ALTER TABLE `gospel_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `income_category_t`
--

DROP TABLE IF EXISTS `income_category_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `income_category_t` (
  `incomecode` int(4) NOT NULL AUTO_INCREMENT,
  `description` varchar(500) NOT NULL DEFAULT '',
  `cancelled` int(1) NOT NULL DEFAULT 0,
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdby` varchar(100) NOT NULL DEFAULT '',
  KEY `ctgcode` (`incomecode`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `income_category_t`
--

LOCK TABLES `income_category_t` WRITE;
/*!40000 ALTER TABLE `income_category_t` DISABLE KEYS */;
INSERT INTO `income_category_t` VALUES (1,'Annual Subscription',0,'2019-02-07 07:16:45',''),(2,'Offerings',0,'2019-02-07 07:16:51',''),(3,'Donation',0,'2019-02-07 07:17:05','');
/*!40000 ALTER TABLE `income_category_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_mail_t`
--

DROP TABLE IF EXISTS `log_mail_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_mail_t` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `userid` varchar(200) NOT NULL,
  `toaddress` varchar(200) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `message` varchar(1000) NOT NULL,
  `activity` varchar(100) NOT NULL,
  `senton` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_mail_t`
--

LOCK TABLES `log_mail_t` WRITE;
/*!40000 ALTER TABLE `log_mail_t` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_mail_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loginactivity_t`
--

DROP TABLE IF EXISTS `loginactivity_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loginactivity_t` (
  `userid` varchar(100) NOT NULL DEFAULT '',
  `logintime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastupdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ipaddress` varchar(100) NOT NULL DEFAULT '',
  `hashkey` varchar(100) NOT NULL DEFAULT '',
  `sessionid` varchar(100) NOT NULL DEFAULT '',
  `hostname` varchar(100) NOT NULL DEFAULT '',
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdby` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loginactivity_t`
--

LOCK TABLES `loginactivity_t` WRITE;
/*!40000 ALTER TABLE `loginactivity_t` DISABLE KEYS */;
INSERT INTO `loginactivity_t` VALUES ('antjosep@gmail.com','2019-02-07 12:52:22','2019-02-07 12:52:22','122.174.182.169','fc4d9ec1031e87737f0f3202d67a4c60','11bb95bf139920cafa8f425cbad49001','','2019-02-07 07:22:22',''),('eliasnvarghese@gmail.com','2020-07-06 03:42:06','2020-07-06 03:42:06','161.69.122.15','bbf3f7d34f8c97aa9ed9b970e48f102b','784226a275978782f668cdb2863518ac','','2020-07-05 22:12:06',''),('ginojohn@gmail.com','2020-07-06 03:42:28','2020-07-06 03:42:28','73.158.59.219','c4c07b88493f8da84802bcd2a7de351a','2698e0bfc09a70f156c0b4ecf7f449d2','','2020-07-05 22:12:28','');
/*!40000 ALTER TABLE `loginactivity_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages_t`
--

DROP TABLE IF EXISTS `messages_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `messages_t` (
  `messageid` int(11) NOT NULL AUTO_INCREMENT,
  `fromuid` varchar(20) NOT NULL DEFAULT '',
  `fromaddress` varchar(100) NOT NULL DEFAULT '',
  `touid` varchar(20) NOT NULL DEFAULT '',
  `toaddress` varchar(100) NOT NULL DEFAULT '',
  `subject` varchar(200) NOT NULL DEFAULT '',
  `message` varchar(1000) NOT NULL DEFAULT '',
  `referance` varchar(100) NOT NULL DEFAULT '',
  `status` int(11) NOT NULL DEFAULT 0,
  `tag` int(11) NOT NULL DEFAULT 0,
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdby` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`messageid`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages_t`
--

LOCK TABLES `messages_t` WRITE;
/*!40000 ALTER TABLE `messages_t` DISABLE KEYS */;
INSERT INTO `messages_t` VALUES (44,'churchteam','churchteam','3441','antjosep@gmail.com','Testing from form','sdfdsfsdafdsafsdafds','',0,0,'2018-11-27 01:50:49',''),(45,'churchteam','churchteam','3441','antjosep@gmail.com','Testing from AGAI','ASDFASDFSDFSDAF','',0,0,'2018-11-27 19:50:26',''),(46,'3441','antjosep@gmail.com','churchteam','churchteam','Hello','sadfasdfasdfsdf','',0,0,'2018-11-27 20:22:27',''),(47,'3441','antjosep@gmail.com','churchteam','churchteam','Testing from form','','',0,0,'2018-11-27 21:40:00',''),(48,'3441','antjosep@gmail.com','churchteam','churchteam','Some Issues','','',0,0,'2018-11-27 21:57:01',''),(49,'3441','antjosep@gmail.com','churchteam','churchteam','testssss','I am testng','',0,0,'2018-11-27 22:00:56','');
/*!40000 ALTER TABLE `messages_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `othermembers_t`
--

DROP TABLE IF EXISTS `othermembers_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `othermembers_t` (
  `memberId` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `name` varchar(40) NOT NULL DEFAULT '',
  `relation` varchar(10) NOT NULL DEFAULT '',
  `gender` varchar(10) NOT NULL DEFAULT '',
  `dob` datetime NOT NULL,
  `deleted` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `othermembers_t`
--

LOCK TABLES `othermembers_t` WRITE;
/*!40000 ALTER TABLE `othermembers_t` DISABLE KEYS */;
INSERT INTO `othermembers_t` VALUES (1,3441,'Jessy Antony','Wife','Female','2018-12-14 00:00:00',0),(2,3441,'Albert Antony','Son','Male','2018-12-16 00:00:00',0);
/*!40000 ALTER TABLE `othermembers_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `postings_t`
--

DROP TABLE IF EXISTS `postings_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `postings_t` (
  `postingid` int(11) NOT NULL AUTO_INCREMENT,
  `contenttype` varchar(10) NOT NULL DEFAULT '',
  `contentid` int(11) NOT NULL DEFAULT 0,
  `videotype` varchar(10) NOT NULL DEFAULT '',
  `videourl` varchar(100) NOT NULL DEFAULT '',
  `videolabel` varchar(100) NOT NULL DEFAULT '',
  `imagetype` varchar(10) NOT NULL DEFAULT '',
  `imagepath` varchar(100) NOT NULL DEFAULT '',
  `title` varchar(100) NOT NULL DEFAULT '',
  `description` varchar(20000) NOT NULL DEFAULT '',
  `posting_like` int(11) NOT NULL DEFAULT 0,
  `deleted` int(1) NOT NULL DEFAULT 0,
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdby` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`postingid`)
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `postings_t`
--

LOCK TABLES `postings_t` WRITE;
/*!40000 ALTER TABLE `postings_t` DISABLE KEYS */;
INSERT INTO `postings_t` VALUES (131,'Video',0,'','https://www.youtube.com/watch?v=8iyq-sEG9xg&list=PLyO3tHZzIoXPgo2lHzt4B3iZv9k2UCXAx','','','','St. Stephen\'s Church Holy Qurbono','St. Stephen\'s Church Holy Qurbono',0,0,'2018-11-26 21:52:03',''),(132,'Video',0,'','https://www.youtube.com/watch?v=hoH0FFQ9jR8','','','','St. Stephen\'s Church Holy Qurbono','St. Stephen\'s Church Holy Qurbono',0,0,'2018-11-26 21:52:03',''),(133,'Video',0,'','https://www.youtube.com/watch?v=7UkSzdCdcfg','','','','St. Stephen\'s Church Holy Qurbono','St. Stephen\'s Church Holy Qurbono',0,0,'2018-11-26 21:52:03',''),(137,'Video',0,'','https://www.youtube.com/watch?v=bAvlQiwFtNE','','','','Gospel Message - November 18 2018','St. Stephen\'s Syriac Orthodox Congregation, San Jose, CA USA. Gospel Message - November 18 2018',0,0,'2018-11-26 22:27:35',''),(138,'Image',0,'','','','image/jpeg','_pic8.jpg','Grand Reception to our Bishop','Grand Reception to our Bishop',0,0,'2018-11-26 22:32:17',''),(139,'Image',0,'','','','image/jpeg','_pic7.jpg','Holy Qurbono','Holy Qurbono',0,0,'2018-11-26 22:33:02',''),(140,'Image',0,'','','','image/jpeg','_pic6.jpg','Holy Qurbono','Holy Qurbono',0,0,'2018-11-26 22:33:26',''),(141,'Image',0,'','','','image/jpeg','_pic6.jpg','Holy Qurbono','Holy Qurbono',0,0,'2018-11-26 22:33:42',''),(142,'Image',0,'','','','image/jpeg','_pic3.jpg','Holy Qurbono','Holy Qurbono',0,0,'2018-11-26 22:34:27',''),(143,'Image',0,'','','','image/jpeg','_pic2.jpg','Holy Qurbono','Holy Qurbono',0,0,'2018-11-26 22:34:52',''),(144,'Video',0,'','https://www.youtube.com/watch?v=7UkSzdCdcfg&feature=youtu.be','','','','Inauguration Song','Inauguration Song',0,0,'2019-01-22 16:06:50',''),(146,'Video',0,'','https://www.youtube.com/watch?v=BTjvNpn6Xgg','','','','First Year (October 2018 - October 2019)','St.Stephen\'s Church San Jose (San Francisco - Bay Area) - First Year (October 2018 - October 2019)',0,0,'2020-07-06 11:03:25',''),(148,'Video',0,'','https://www.youtube.com/watch?v=qUON28yKHeE','','','','Sunday - May 5 2019 - Gospel reading','Sunday - May 5 2019 - Gospel reading',0,0,'2020-07-06 11:05:50',''),(149,'Video',0,'','https://www.youtube.com/watch?v=O8VYxtw0mhs','','','','Ecumenical Carol 2018 - San Jose CA','Ecumenical Carol 2018 - San Jose CA',0,0,'2020-07-06 11:07:02',''),(150,'Video',0,'','https://www.youtube.com/watch?v=JHmqbKYPtOw','','','','January 13 2019 - Feast of St.Stephens - Gospel Message','January 13 2019 - Feast of St.Stephens - Gospel Message',0,0,'2020-07-06 11:08:14',''),(151,'Video',0,'','https://www.youtube.com/watch?v=I23UXaHkOYA','','','','2019 Hosanna - April 14 2019 - Gospel Reading','2019 Hosanna - April 14 2019 - Gospel Reading',0,0,'2020-07-06 11:09:23',''),(152,'Video',0,'','https://www.youtube.com/watch?v=l9iHedd15hg','','','','Message by Rev. Fr. Paul Thotakat','Message by Rev. Fr. Paul Thotakat',0,0,'2020-07-06 11:11:15',''),(153,'Video',0,'','https://www.youtube.com/watch?v=vpcjVlsLWmQ','','','','2020 Lent - Easter - Archbishop Yeldho Mor Titus','2020 Lent - Easter - Archbishop Yeldho Mor Titus',0,0,'2020-07-06 11:11:56',''),(154,'Video',0,'','https://www.youtube.com/watch?v=Cto8_wgZGC8','','','','Fathers Day 2020','Fathers Day 2020',0,0,'2020-07-06 11:12:42',''),(155,'Video',0,'','https://www.youtube.com/watch?v=Xh1hHl3TPwg','','','','July 5 2020 - Gospel Reading - H.E. Yeldho Mor Titus','July 5 2020 - Gospel Reading - H.E. Yeldho Mor Titus',0,0,'2020-07-06 11:13:52',''),(156,'Video',0,'','https://www.youtube.com/watch?v=PA459MgavbE','','','','Intercessory Prayer to St. Mary & St.Thomas','Intercessory Prayer to St. Mary & St.Thomas',0,0,'2020-07-06 11:14:42',''),(157,'Video',0,'','https://www.youtube.com/watch?v=Cw5-dUD5zHw','','','','July 5 2020 - Gospel Message - H.E. Yeldho Mor Titus','July 5 2020 - Gospel Message - H.E. Yeldho Mor Titus',0,0,'2020-07-06 11:15:03',''),(158,'Image',0,'','','','image/jpeg','_picvolunteer-hope-1.jpg','Volunteer - San Jose - 1','Volunteer - San Jose - 1',0,0,'2020-07-06 11:25:17',''),(159,'Image',0,'','','','image/jpeg','_picvolunteer-hope-2.jpg','Volunteer - San Jose - 2','Volunteer - San Jose - 2',0,0,'2020-07-06 11:25:36',''),(160,'Image',0,'','','','image/jpeg','_picvbs-1.jpg','VBS 2019 - 1','VBS 2019 - 1',0,0,'2020-07-06 11:26:03',''),(161,'Image',0,'','','','image/jpeg','_picvbs-2.jpg','VBS 2019 - 2','VBS 2019 - 2',0,0,'2020-07-06 11:26:19',''),(162,'Image',0,'','','','image/jpeg','_picsunday_school-1.jpg','Sunday School - 1','Sunday School - 1',0,0,'2020-07-06 11:26:53',''),(163,'Image',0,'','','','image/jpeg','_picsunday_school-2.jpg','Sunday School - 2','Sunday School - 2',0,0,'2020-07-06 11:27:06',''),(164,'Image',0,'','','','image/jpeg','_picpicnic-1.jpg','Picnic 2019 - 1','Picnic 2019 - 1',0,0,'2020-07-06 11:27:37',''),(165,'Image',0,'','','','image/jpeg','_picpicnic-2.jpg','Picnic 2019 - 2','Picnic 2019 - 2',0,0,'2020-07-06 11:27:55',''),(166,'Image',0,'','','','image/jpeg','_piccalendar.jpg','Calendar','Calendar',0,0,'2020-07-06 11:38:45',''),(167,'Image',0,'','','','image/jpeg','_picmalayalam_class.jpg','Malayalam Class','Malayalam Class',0,0,'2020-07-06 11:40:47',''),(168,'Image',0,'','','','image/jpeg','_picmalayalam_class_flyer.jpg','Malayalam Class Flyer','Malayalam Class Flyer',0,0,'2020-07-06 11:44:18',''),(169,'Image',0,'','','','image/jpeg','_picthirumeni_meeting.jpg','Thirumeni Meeting - June 2020','Thirumeni Meeting - June 2020',0,0,'2020-07-06 11:45:13',''),(170,'Image',0,'','','','image/jpeg','_picfr.paul-1.jpg','Rev. Fr. Paul Thotakkat ','Rev. Fr. Paul Thotakkat ',0,0,'2020-07-06 12:06:20',''),(171,'Image',0,'','','','image/jpeg','_picfr.paul-2.jpg','Rev. Fr. Paul Thotakkat ','Rev. Fr. Paul Thotakkat ',0,0,'2020-07-06 12:06:34','');
/*!40000 ALTER TABLE `postings_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spl_events_t`
--

DROP TABLE IF EXISTS `spl_events_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spl_events_t` (
  `eventid` int(11) NOT NULL AUTO_INCREMENT,
  `fromdate` datetime NOT NULL,
  `todate` datetime NOT NULL,
  `highlights` varchar(200) DEFAULT '',
  `eventdetails` longtext NOT NULL,
  `clickscount` int(11) NOT NULL DEFAULT 0,
  `eventname` varchar(100) NOT NULL DEFAULT '',
  `deleted` int(1) NOT NULL DEFAULT 0,
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdby` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`eventid`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spl_events_t`
--

LOCK TABLES `spl_events_t` WRITE;
/*!40000 ALTER TABLE `spl_events_t` DISABLE KEYS */;
INSERT INTO `spl_events_t` VALUES (1,'2019-03-06 00:00:00','2019-03-06 00:00:00','Ash Wednesday','Ash Wednesday',0,'Ash Wednesday',1,'2019-03-05 23:45:34',''),(2,'2024-02-11 00:00:00','2024-02-11 00:00:00','1st Sunday - Feast of Cana (qotnÃ© )','Feast of Cana (qotnÃ© )\r\n\r\nHoly Qurbono: 8:30 AM',0,'1st Sunday of Lent',0,'2024-02-05 12:44:52',''),(3,'2024-02-18 00:00:00','2024-02-18 00:00:00','2nd Sunday - The Sunday of leper (garbo)','The Sunday of leper (garbo)\r\n\r\nHoly Qurbono: 8:30 AM',0,'2nd Sunday of Lent',0,'2024-02-05 12:45:24',''),(4,'2019-03-13 00:00:00','2019-03-13 00:00:00','March 13 - Wednesday','Evening Prayer : 8:30 PM',0,'March 13 - Wednesday',1,'2019-03-12 17:43:07',''),(8,'2019-03-17 00:00:00','2019-03-17 00:00:00','March 17 - Sunday','Holy Qurbono - 8:00 AM',0,'March 17 - Sunday',1,'2019-03-12 17:46:48',''),(5,'2019-03-14 00:00:00','2019-03-14 00:00:00','March 14 - Thursday','Evening Prayer - 8:30 PM',0,'March 14 - Thursday',1,'2019-03-12 17:39:26',''),(6,'2019-03-15 00:00:00','2019-03-15 00:00:00','March 15 - Friday','Evening Prayer - 8:30 PM',0,'March 15 - Friday',1,'2019-03-12 17:40:00',''),(7,'2019-03-16 00:00:00','2019-03-16 00:00:00','March 16 - Saturday','Evening Prayer : 8:30 PM',0,'March 16 - Saturday',1,'2019-03-12 17:40:56',''),(9,'2024-02-25 00:00:00','2024-02-25 00:00:00','Sunday of The Paralytic(msharyo)','Sunday of The Paralytic (msharyo)\r\n\r\nHoly Qurbono: 8:30 AM',0,'3rd Sunday of Lent',0,'2024-02-05 12:45:42',''),(10,'2024-03-03 00:00:00','2024-03-03 00:00:00','Sunday of the Canaanite woman (kna`nayto)','Sunday of the Canaanite woman (kna`nayto)\r\n\r\nHoly Qurbono: 8:30 AM',0,'4th Sunday of Lent',0,'2024-02-05 12:46:17',''),(11,'2024-03-10 00:00:00','2024-03-10 00:00:00','Sunday of the hunchback woman (kfofto)','Sunday of the hunchback woman (kfofto)\r\n\r\nHoly Qurbono: 8:30 AM',0,'5th Sunday of Lent',0,'2024-02-05 12:46:34',''),(12,'2024-03-17 00:00:00','2024-03-17 00:00:00','Sunday of the healing of the Blind man (Samyo)','Sunday of the healing of the Blind man (Samyo)\r\n\r\nHoly Qurbono:  8:30 AM',0,'6th Sunday of Lent',0,'2024-02-05 12:46:59',''),(13,'2024-03-24 00:00:00','2024-03-24 00:00:00','Palm Sunday (oosha`nÃ©)','Palm Sunday (oosha`nÃ©)\r\n\r\nPalm Sunday Service & Holy Qurbono: 7:30 AM',0,'Palm Sunday (oosha`nÃ©)',0,'2024-02-05 12:47:49',''),(14,'2024-03-23 00:00:00','2024-03-23 00:00:00','Lenten Retreat','Lenten Retreat & Evening Prayer\r\n\r\nTime: 2 PM - 5:00 PM\r\n',0,'Lenten Retreat (Saturday)',0,'2024-02-05 12:47:24',''),(15,'2024-03-27 00:00:00','2024-03-27 00:00:00','Pesaha','Pesaha\r\n\r\nEvening Prayer: 6:00 PM\r\nPesaha Qurbono: 7:00 PM\r\n',0,'Pesaha (Wednesday Evening)',0,'2024-02-05 12:48:10',''),(16,'2024-03-29 00:00:00','2024-03-29 00:00:00','Good Friday','Good Friday\r\n\r\nMorning Prayer: 8:00 AM\r\nGood Friday Service: 9:00 AM',0,'Good Friday',0,'2024-02-05 12:48:28',''),(17,'2024-03-30 00:00:00','2024-03-30 00:00:00','Easter(Sunday of resurrection)','Easter(Sunday of resurrection)\r\n\r\nEvening Prayer: 5:00 PM\r\nEaster Service & Holy Qurbono: 6:00 PM',0,'Easter (Saturday Evening)',0,'2024-02-05 12:48:44','');
/*!40000 ALTER TABLE `spl_events_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `todo_list_t`
--

DROP TABLE IF EXISTS `todo_list_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `todo_list_t` (
  `todo_id` int(4) NOT NULL AUTO_INCREMENT,
  `client_id` varchar(20) NOT NULL DEFAULT '',
  `todo_date` datetime DEFAULT NULL,
  `description` varchar(500) NOT NULL DEFAULT '',
  `cancelled` int(1) NOT NULL DEFAULT 0,
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdby` varchar(100) NOT NULL DEFAULT '',
  KEY `todo_id` (`todo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `todo_list_t`
--

LOCK TABLES `todo_list_t` WRITE;
/*!40000 ALTER TABLE `todo_list_t` DISABLE KEYS */;
/*!40000 ALTER TABLE `todo_list_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `useraccount_t`
--

DROP TABLE IF EXISTS `useraccount_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `useraccount_t` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `userid` varchar(100) NOT NULL DEFAULT '',
  `username` varchar(100) NOT NULL,
  `passwd` varchar(100) NOT NULL DEFAULT '',
  `saltkey` varchar(200) NOT NULL DEFAULT '',
  `sessionid` varchar(200) NOT NULL DEFAULT '',
  `activationdata` varchar(200) NOT NULL DEFAULT '',
  `otp` varchar(50) DEFAULT '',
  `otpvalidtill` timestamp NULL DEFAULT NULL,
  `activated` int(11) NOT NULL DEFAULT 0,
  `activatedon` datetime NOT NULL,
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdby` varchar(100) NOT NULL DEFAULT '',
  `deleted` int(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=3452 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `useraccount_t`
--

LOCK TABLES `useraccount_t` WRITE;
/*!40000 ALTER TABLE `useraccount_t` DISABLE KEYS */;
INSERT INTO `useraccount_t` VALUES (3441,'antjosep@gmail.com','','nt/l3YunaQ==','qqnZu6fK26SPlqWUmp+SdZeVd5ajpJSfnpo=','kl4gfja116po3ul3h1bteeojp5','k6/X3tjpxuSp1tulyuCPrtTmZGBiblpiYFpiYEBgcnRmbnRiZA==','','2017-11-04 11:24:12',1,'2017-10-02 14:44:31','2017-10-02 16:14:31','',0),(3449,'ginojohn@gmail.com','','pN671XmqbKI=','uMfHx9nV2M3Tsavd59XLmo+WppSan5KFrHOlmaqcl6h3nA==','1e4119d8a6d07d4c46663a52a7d88e78','','',NULL,1,'0000-00-00 00:00:00','2018-11-28 09:12:44','',0),(3451,'eliasnvarghese@gmail.com','','ouG2x7upa6E=','uMfHx9nV2M3Tsavd59XLmo+XnpSZpZKDqnOkmKqclqh4mg==','51302fa7f6b0eeebacd895e8d37501d2','','',NULL,1,'0000-00-00 00:00:00','2020-07-05 22:09:22','',0);
/*!40000 ALTER TABLE `useraccount_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `useractivity_t`
--

DROP TABLE IF EXISTS `useractivity_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `useractivity_t` (
  `activityid` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(20) NOT NULL DEFAULT '',
  `activityperformed` varchar(1000) NOT NULL DEFAULT '',
  `hostname` varchar(100) NOT NULL DEFAULT '',
  `useragent` varchar(2000) NOT NULL DEFAULT ' ',
  `createdon` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdby` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`activityid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `useractivity_t`
--

LOCK TABLES `useractivity_t` WRITE;
/*!40000 ALTER TABLE `useractivity_t` DISABLE KEYS */;
/*!40000 ALTER TABLE `useractivity_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userregistration_t`
--

DROP TABLE IF EXISTS `userregistration_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userregistration_t` (
  `uid` int(11) NOT NULL,
  `userid` varchar(50) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `familyname` varchar(100) NOT NULL DEFAULT '',
  `gender` varchar(10) NOT NULL DEFAULT '',
  `dob` date NOT NULL,
  `qualification` varchar(100) NOT NULL DEFAULT '',
  `fulladdress` varchar(500) NOT NULL DEFAULT '',
  `zipcode` varchar(10) NOT NULL DEFAULT '0',
  `city` varchar(100) NOT NULL DEFAULT '',
  `state` varchar(100) NOT NULL DEFAULT '',
  `mobilenumber` varchar(20) NOT NULL DEFAULT '',
  `phonenumber` varchar(20) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `photopath` varchar(1000) NOT NULL DEFAULT '',
  `aboutme` varchar(1000) DEFAULT '',
  `aboutfamily` varchar(1000) NOT NULL DEFAULT '',
  `maritalstatus` varchar(20) NOT NULL DEFAULT '',
  `spousename` varchar(100) NOT NULL DEFAULT '',
  `deleted` int(1) NOT NULL DEFAULT 0,
  `completedstage` int(1) NOT NULL DEFAULT 0,
  `lastlogintime` timestamp NOT NULL DEFAULT current_timestamp(),
  `createdon` datetime NOT NULL,
  `createdby` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userregistration_t`
--

LOCK TABLES `userregistration_t` WRITE;
/*!40000 ALTER TABLE `userregistration_t` DISABLE KEYS */;
INSERT INTO `userregistration_t` VALUES (3441,'antjosep@gmail.com','Antony Joseph','Kuruppassery','Male','1962-12-19','','3 B Penta Lakshmi Apartments, Edappally','','Ernakulam','Kerala','9400293500',' ','antjosep@gmail.com','','Freelance Web Developer ','Let me tell you about my family. ','','',0,0,'2017-10-02 16:14:31','2017-10-02 14:44:31',''),(3449,'ginojohn@gmail.com','Gino John','Family Name Here','Male','1970-02-11','','111111 ','','Sanjose','CA','1111111111111','22222222222','ginojohn@gmail.com','','Software Professional','2 Kids Studying.','','',0,0,'2018-11-28 09:12:44','2018-11-28 14:42:44',''),(3450,'m2eliasnv@gmail.com','Elias N Varghese','N','Male','1970-01-01','','Mountain House','','Mountain House','CA','0000','000','m2eliasnv@gmail.com','','','','Married','Anila',0,0,'2020-07-05 21:21:50','2020-07-06 02:51:50',''),(3451,'eliasnvarghese@gmail.com','Elias N Varghese','N','Male','2020-07-05','','Mountain House','','Mountain House','CA','0000','0000000000','eliasnvarghese@gmail.com','','','','Married','Anila',0,0,'2020-07-05 22:09:22','2020-07-06 03:39:22','');
/*!40000 ALTER TABLE `userregistration_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ststephenchurchdb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-06 20:29:57
